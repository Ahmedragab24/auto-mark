(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__317cb5._.css",
    "static/chunks/src_a07066._.js",
    "static/chunks/node_modules_next_986a6e._.js",
    "static/chunks/node_modules_@reduxjs_toolkit_dist_3b8977._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_crypto-js_e5d7b1._.js",
    "static/chunks/node_modules_@firebase_auth_dist_esm2017_9c3c0a._.js",
    "static/chunks/node_modules_framer-motion_dist_es_543d59._.js",
    "static/chunks/node_modules_@radix-ui_a219b7._.js",
    "static/chunks/node_modules_@floating-ui_9ec1fa._.js",
    "static/chunks/node_modules_@firebase_74c10d._.js",
    "static/chunks/node_modules_71f1bd._.js"
  ],
  "source": "dynamic"
});
