(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_not-found_tsx_0666ed._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_not-found_tsx_0666ed._.js",
  "chunks": [
    "static/chunks/_ad8ad0._.js"
  ],
  "source": "dynamic"
});
