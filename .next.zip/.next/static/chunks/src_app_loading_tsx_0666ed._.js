(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_loading_tsx_0666ed._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_loading_tsx_0666ed._.js",
  "chunks": [
    "static/chunks/src_dc560f._.js"
  ],
  "source": "dynamic"
});
